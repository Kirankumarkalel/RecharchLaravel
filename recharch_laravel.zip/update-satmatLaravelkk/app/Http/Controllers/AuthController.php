<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Illuminate\Support\Facades\Http;

class AuthController extends Controller
{
    public function showLoginForm()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $request->validate([
            'username' => 'required|string',
            'password' => 'required|string',
        ]);

        $credentials = $request->only('username', 'password');

        $username = User::where('username', $credentials['username'])->first();
        $password = User::where('password', $credentials['password'])->first();

        if ($username && $password) {
            
            Auth::login($username);
            return redirect()->route('dashboard');
        } else {
            return redirect()->back()->withErrors(['username' => 'Invalid credentials']);
        }
    }

    public function logout()
    {
        Auth::logout();
        return redirect()->route('login');
    }

    

    public function showApiData(Request $request)
    {
        $operator = $request->operator;
        $number = $request->mobileNo;
        $amount = $request->amount;
    
        // Example API URL with dynamic parameters
        $apiUrl = 'https://intern.satmatgroup.com/mynewrechargeapp/recharge_api/recharge?member_id=9876543210&api_password=1234&api_pin=1234&number=' . $number . '&amount=' . $amount . '&operator=' . $operator;
    
        // Fetch the API data
        $response = Http::get($apiUrl);
    
        if ($response->successful()) {
            $data = $response->json();
        } else {
            $data = ['error' => 'Unable to fetch data from the API'];
        }
    
        return response()->json($data);
    }

    

    public function showDashboard()
    {
    
        return view('dashboard');
    }
}
