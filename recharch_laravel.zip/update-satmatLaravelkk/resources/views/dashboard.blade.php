<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prepaid Recharge</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

    <style>
        .imgsize {
            width: 47px;
            height: 45px;
            border-radius: 10px;
        }

        .btn-primary {
            color: #fff;
            background-color: #e11175b3 !important;
            border-color: #e11175b3;
        }

        .mt-5, .my-5 {
            margin-top: 2rem !important;
        }

        .radioclass {
            margin-left: 21px !important;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="">
                    <div class="">
                        <h3>YOUR PREPAID DETAILS <a class="float-right" href="{{ route('logout') }}">logout</a></h3>
                    </div>
                    <div class="card-body">
                        <form id="rechargeForm">
                            @csrf
                            <div class="form-group">
                                <label>Select Operator:</label>
                                <div class="row">
                                    <div class="col-md-2">
                                        <p class="radioclass">
                                            <input class="form-check-input" type="radio" name="operator" id="airtel" value="airtel">
                                        </p>
                                        <p class="mt-4">
                                            <img class="imgsize" src="{{ asset('images/airtel.png') }}" alt="Airtel" width="50" height="50">
                                        </p>
                                        <p>
                                            <label class="form-check-label" for="airtel">AIRTEL</label>
                                        </p>
                                    </div>
                                    <div class="col-md-2">
                                        <p class="radioclass">
                                            <input class="form-check-input" type="radio" name="operator" id="bsnl" value="bsnl">
                                        </p>
                                        <p class="mt-4">
                                            <img class="imgsize" src="{{ asset('images/bsnl.png') }}" alt="BSNL" width="50" height="50">
                                        </p>
                                        <p>
                                            <label class="form-check-label" for="bsnl">BSNL</label>
                                        </p>
                                    </div>
                                    <div class="col-md-2">
                                        <p class="radioclass">
                                            <input class="form-check-input" type="radio" name="operator" id="bsnlstv" value="bsnlstv">
                                        </p>
                                        <p class="mt-4">
                                            <img class="imgsize" src="{{ asset('images/stv.jpg') }}" alt="BSNL STV" width="50" height="50">
                                        </p>
                                        <p>
                                            <label class="form-check-label" for="bsnlstv">BSNL STV</label>
                                        </p>
                                    </div>
                                    <div class="col-md-2">
                                        <p class="radioclass">
                                            <input class="form-check-input" type="radio" name="operator" id="idea" value="idea">
                                        </p>
                                        <p class="mt-4">
                                            <img class="imgsize" src="{{ asset('images/idea.png') }}" alt="Idea" width="50" height="50">
                                        </p>
                                        <p>
                                            <label class="form-check-label" for="idea">IDEA</label>
                                        </p>
                                    </div>
                                    <div class="col-md-2">
                                        <p class="radioclass">
                                            <input class="form-check-input" type="radio" name="operator" id="jio" value="jio">
                                        </p>
                                        <p class="mt-4">
                                            <img class="imgsize" src="{{ asset('images/jio.png') }}" alt="Jio" width="50" height="50">
                                        </p>
                                        <p>
                                            <label class="form-check-label" for="jio">JIO</label>
                                        </p>
                                    </div>
                                    <div class="col-md-2">
                                        <p class="radioclass">
                                            <input class="form-check-input" type="radio" name="operator" id="vodafone" value="vodafone">
                                        </p>
                                        <p class="mt-4">
                                            <img class="imgsize" src="{{ asset('images/vodaphone.jpg') }}" alt="Vodafone" width="50" height="50">
                                        </p>
                                        <p>
                                            <label class="form-check-label" for="vodafone">VODAFONE</label>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="mobileNo">ENTER PREPAID MOBILE NO:</label>
                                <input type="text" class="form-control" id="mobileNo" name="mobileNo" placeholder="Enter your mobile number">
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-8">
                                        <label for="amount">ENTER REACHARGE AMOUNT:</label>
                                        <input type="number" class="form-control" id="amount" name="amount" placeholder="Enter recharge amount">
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mt-5">
                                            <button type="submit" class="btn btn-primary btn-block">Plan</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary btn-block">Proceed to Recharge</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#rechargeForm').on('submit', function(event) {
                event.preventDefault(); // Prevent the default form submission

                $.ajax({
                    url: "{{ route('postapidata') }}",
                    method: "POST",
                    data: $(this).serialize(),
                    success: function(response) {
                        alert("Response: " + response.MESSAGE);
                    },
                    error: function(xhr, status, error) {
                        alert("An error occurred: " + xhr.responseText);
                    }
                });
            });
        });
    </script>
</body>
</html>
